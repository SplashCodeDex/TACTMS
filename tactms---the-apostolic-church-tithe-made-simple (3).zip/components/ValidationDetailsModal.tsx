import React from 'react';

const ValidationDetailsModal: React.FC = () => {
    return null;
};

export default ValidationDetailsModal;
